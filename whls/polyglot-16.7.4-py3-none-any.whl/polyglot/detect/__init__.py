from .base import Detector, Language

__all__ = ['Detector', 'Language']
